import SuperAdminDashboard from "../../Layouts/SuperAdminDashboard";
import Dashboard from "../components/Dashboard";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import Usertable from "../components/Usertable"
import Ownerinfo from "../components/Ownerinfo"
import Calendar from "../components/Calendar";
import ProfileInfo from "../components/Profileinfo";
import CustomerReview from "../components/CustomerReview"
import Rentalform from "../components/Rentalform";
import Settings from "../components/Settings";
import Mail from "../components/Mail";
import Notifications from "../components/Notifications";

function Admin() {
  return (
    <>
    <Routes>


    <Route path="/" element={<SuperAdminDashboard />}>
        <Route index element={<Dashboard />} />
        
        <Route path="/Usertable" element={<Usertable />} />
        <Route path="/Ownerinfo" element={<Ownerinfo />} />
        <Route path="/Reviews" element={<CustomerReview />} />

        <Route path="/Calendar" element={<Calendar />} />
        <Route path="/Settings" element={<Settings />} />
        <Route path="/Notifications" element={<Notifications/>} />


        <Route path="/Profile-info" element={<ProfileInfo />} />
        <Route path="/Mail" element={<Mail/>} />

      </Route>

    </Routes>
    
      
       
    
    
    </>
   
  );
}

export default Admin;
