import React from "react";
import Star from "../../@UI/Star";
import { useState } from "react";


function Mail(open,setOpen){
    
    const [selectedEmail, setSelectedEmail] = useState(null);
    const emails = [
        {
          id: 1,
          subject: 'Welcome To Our RV Boutique!',
          sender: 'ravi@example.com',
          time:'12:30',
          body: 'We are thrilled to welcome you to Our RV Boutique, a carefully curated space where fashion meets individuality. Whether you are looking for timeless classics, trendsetting pieces, or that perfect finishing touch, our boutique was designed with you in mind.',
          content:'Step into our world and explore our Handpicked styles, Unique accessories and A cozy, personalized shopping experience',
          last:'We are excited to have you here. Let us know if you need anything!',
          
        },
        {
          id: 2,
          subject: 'Your April Offer',
          sender: 'shakthi@example.com',
          time:'9:30',
          body: 'Spring is in full bloom, and so are our April specials. To celebrate the season and our amazing customers, we are offering you an exclusive April deal: 15% Off All Purchases | Free Gift with Every Order | Buy 1 Get 1 50% Offer.',
          content:'Introduce new items or collections with a focus on their features and benefits. To engaging and informative, highlighting seasonal promotions, holiday celebrations, and potentially new product launches or updates.',
          last:'Valid from April 1 to April 30. Thank you for your Support!',
        },
        {
          id: 3,
          subject: 'Welcome To Our College',
          sender: 'smvec@example.com',
          time:'4:30',
          body: 'We are pleased to invite you to the Parents Meeting scheduled to be held on [21-11-2025] at [10 am] in the [SMVEC/Auditorium]. This meeting aims to strengthen the collaboration between the college and parents to ensure the academic progress and well-being of our students.',
          content:'We wish you all the very best in your future endeavors, and we hope you know that we will always remember your contributions with great appreciation and fondness.',
          last:'Thank you for your years of dedicated service to our school, and for the countless ways you have touched the lives of our students and colleagues.',
        },

        {
            id: 4,
            subject: 'Welcome To Our College',
            sender: 'smvec@example.com',
            time:'4:30',
            body: 'We are pleased to invite you to the Parents Meeting scheduled to be held on [21-11-2025] at [10 am] in the [SMVEC/Auditorium]. This meeting aims to strengthen the collaboration between the college and parents to ensure the academic progress and well-being of our students.',
            content:'We wish you all the very best in your future endeavors, and we hope you know that we will always remember your contributions with great appreciation and fondness.',
            last:'Thank you for your years of dedicated service to our school, and for the countless ways you have touched the lives of our students and colleagues.',
          },
          {
            id: 5,
            subject: 'Welcome To Our College',
            sender: 'smvec@example.com',
            time:'4:30',
            body: 'We are pleased to invite you to the Parents Meeting scheduled to be held on [21-11-2025] at [10 am] in the [SMVEC/Auditorium]. This meeting aims to strengthen the collaboration between the college and parents to ensure the academic progress and well-being of our students.',
            content:'We wish you all the very best in your future endeavors, and we hope you know that we will always remember your contributions with great appreciation and fondness.',
            last:'Thank you for your years of dedicated service to our school, and for the countless ways you have touched the lives of our students and colleagues.',
          },
          {
            id: 6,
            subject: 'Welcome To Our College',
            sender: 'smvec@example.com',
            time:'4:30',
            body: 'We are pleased to invite you to the Parents Meeting scheduled to be held on [21-11-2025] at [10 am] in the [SMVEC/Auditorium]. This meeting aims to strengthen the collaboration between the college and parents to ensure the academic progress and well-being of our students.',
            content:'We wish you all the very best in your future endeavors, and we hope you know that we will always remember your contributions with great appreciation and fondness.',
            last:'Thank you for your years of dedicated service to our school, and for the countless ways you have touched the lives of our students and colleagues.',
          },


      ];
    

    return(
        <>
        <div className="">
            <div className="mx-4 flex flex-wrap items-center justify-between gap-3 mb-6">
                <h2 className="text-xl  font-semibold text-gray-800 dark:text-white/90" x-text="pageName">Inbox</h2>
                <nav>
                    <ol className="flex items-center gap-1.5">
                    <li>
                        <a className="inline-flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400" href="#">Home
                        <svg className="stroke-current" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6.0765 12.667L10.2432 8.50033L6.0765 4.33366" stroke="" strokeWidth="1.2" strokeLinecap="round" stroke-linejoin="round"></path>
                        </svg>
                        </a>
                    </li>
                    <li className="text-sm text-gray-800 dark:text-white/90" x-text="pageName">Inbox</li>
                    </ol>
                </nav>
            </div>
        </div>

           

        <div className=" w-[200%] h-full flex">
            <div
        className={`fixed top-0 ${
          open ? "right-0" : "-right-full"
        } md:relative md:left-0 md:right-auto md:block h-full rounded-2xl bg-background text-black px-4 z-40
          w-20% transition-all duration-500`} >

        <div className="mt-4 flex flex-col gap-4">
            <div className="mt-1 grid grid-cols-1 justify-center pb-5">
                <button className="mx-1 flex w-[170px] items-center justify-center gap-2 rounded-lg bg-[#FF0000] p-3 text-[15px] font-medium text-white shadow-theme-xs hover:bg-brand-600">
                    <svg className="fill-current" width="21" height="20" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.0911 3.03206C16.2124 2.15338 14.7878 2.15338 13.9091 3.03206L5.6074 11.3337C5.29899 11.6421 5.08687 12.0335 4.99684 12.4603L4.26177 15.945C4.20943 16.1931 4.286 16.4508 4.46529 16.6301C4.64458 16.8094 4.90232 16.8859 5.15042 16.8336L8.63507 16.0985C9.06184 16.0085 9.45324 15.7964 9.76165 15.488L18.0633 7.18631C18.942 6.30763 18.942 4.88301 18.0633 4.00433L17.0911 3.03206ZM14.9697 4.09272C15.2626 3.79982 15.7375 3.79982 16.0304 4.09272L17.0027 5.06499C17.2956 5.35788 17.2956 5.83276 17.0027 6.12565L16.1043 7.02402L14.0714 4.99109L14.9697 4.09272ZM13.0107 6.05175L6.66806 12.3944C6.56526 12.4972 6.49455 12.6277 6.46454 12.7699L5.96704 15.1283L8.32547 14.6308C8.46772 14.6008 8.59819 14.5301 8.70099 14.4273L15.0436 8.08468L13.0107 6.05175Z" fill=""></path>
                    </svg>Compose
                </button>

            <div>
                <h3 className="mb-3 mt-6 text-xs  uppercase font-bold text-gray-700 dark:text-gray-400">MAILBOX</h3>

                <ul className="flex flex-col gap-1">
                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="group flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 bg-brand-50 dark:text-gray-400 dark:bg-brand-500/[0.12]">
                        <span className="flex items-center gap-3">
                            <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.2996 1.12891C11.4713 1.12891 10.7998 1.80033 10.7996 2.62867L10.7996 3.1264V3.12659L10.7997 4.87507H6.14591C3.6031 4.87507 1.54175 6.93642 1.54175 9.47923V14.3207C1.54175 15.4553 2.46151 16.3751 3.5961 16.3751H6.14591H10.0001H16.2084C17.4511 16.3751 18.4584 15.3677 18.4584 14.1251V10.1251C18.4584 7.22557 16.1079 4.87507 13.2084 4.87507H12.2997L12.2996 3.87651H13.7511C14.5097 3.87651 15.1248 3.26157 15.1249 2.50293C15.125 1.74411 14.5099 1.12891 13.7511 1.12891H12.2996ZM3.04175 9.47923C3.04175 7.76485 4.43153 6.37507 6.14591 6.37507C7.8603 6.37507 9.25008 7.76485 9.25008 9.47923V14.8751H6.14591H3.5961C3.28994 14.8751 3.04175 14.6269 3.04175 14.3207V9.47923ZM10.7501 9.47923V14.8751H16.2084C16.6226 14.8751 16.9584 14.5393 16.9584 14.1251V10.1251C16.9584 8.054 15.2795 6.37507 13.2084 6.37507H9.54632C10.294 7.19366 10.7501 8.28319 10.7501 9.47923Z" fill=""></path>
                            </svg>
                            Inbox
                        </span>
                        <span >3</span>
                        </a>
                    </li>

                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 dark:text-gray-400" >
                        <span className="flex items-center gap-3">
                            <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M4.98481 2.44399C3.11333 1.57147 1.15325 3.46979 1.96543 5.36824L3.82086 9.70527C3.90146 9.89367 3.90146 10.1069 3.82086 10.2953L1.96543 14.6323C1.15326 16.5307 3.11332 18.4291 4.98481 17.5565L16.8184 12.0395C18.5508 11.2319 18.5508 8.76865 16.8184 7.961L4.98481 2.44399ZM3.34453 4.77824C3.0738 4.14543 3.72716 3.51266 4.35099 3.80349L16.1846 9.32051C16.762 9.58973 16.762 10.4108 16.1846 10.68L4.35098 16.197C3.72716 16.4879 3.0738 15.8551 3.34453 15.2223L5.19996 10.8853C5.21944 10.8397 5.23735 10.7937 5.2537 10.7473L9.11784 10.7473C9.53206 10.7473 9.86784 10.4115 9.86784 9.99726C9.86784 9.58304 9.53206 9.24726 9.11784 9.24726L5.25157 9.24726C5.2358 9.20287 5.2186 9.15885 5.19996 9.11528L3.34453 4.77824Z" fill=""></path>
                            </svg>
                            Sent
                        </span>
                        </a>
                    </li>

                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 dark:text-gray-400" >
                        <span className="flex items-center gap-3">
                            <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M3.04175 7.06206V14.375C3.04175 14.6511 3.26561 14.875 3.54175 14.875H16.4584C16.7346 14.875 16.9584 14.6511 16.9584 14.375V7.06245L11.1443 11.1168C10.457 11.5961 9.54373 11.5961 8.85638 11.1168L3.04175 7.06206ZM16.9584 5.19262C16.9584 5.19341 16.9584 5.1942 16.9584 5.19498V5.20026C16.9572 5.22216 16.946 5.24239 16.9279 5.25501L10.2864 9.88638C10.1145 10.0062 9.8862 10.0062 9.71437 9.88638L3.07255 5.25485C3.05342 5.24151 3.04202 5.21967 3.04202 5.19636C3.042 5.15695 3.07394 5.125 3.11335 5.125H16.8871C16.9253 5.125 16.9564 5.15494 16.9584 5.19262ZM18.4584 5.21428V14.375C18.4584 15.4796 17.563 16.375 16.4584 16.375H3.54175C2.43718 16.375 1.54175 15.4796 1.54175 14.375V5.19498C1.54175 5.1852 1.54194 5.17546 1.54231 5.16577C1.55858 4.31209 2.25571 3.625 3.11335 3.625H16.8871C17.7549 3.625 18.4584 4.32843 18.4585 5.19622C18.4585 5.20225 18.4585 5.20826 18.4584 5.21428Z" fill=""></path>
                            </svg>
                            Drafts
                        </span>
                        </a>
                    </li>

                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="group flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 dark:text-gray-400">
                        <span className="flex items-center gap-3">
                            <svg className=" text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.2996 1.12891C11.4713 1.12891 10.7998 1.80033 10.7996 2.62867L10.7996 3.1264V3.12659L10.7997 4.87507H6.14591C3.6031 4.87507 1.54175 6.93642 1.54175 9.47923V14.3207C1.54175 15.4553 2.46151 16.3751 3.5961 16.3751H6.14591H10.0001H16.2084C17.4511 16.3751 18.4584 15.3677 18.4584 14.1251V10.1251C18.4584 7.22557 16.1079 4.87507 13.2084 4.87507H12.2997L12.2996 3.87651H13.7511C14.5097 3.87651 15.1248 3.26157 15.1249 2.50293C15.125 1.74411 14.5099 1.12891 13.7511 1.12891H12.2996ZM3.04175 9.47923C3.04175 7.76485 4.43153 6.37507 6.14591 6.37507C7.8603 6.37507 9.25008 7.76485 9.25008 9.47923V14.8751H6.14591H3.5961C3.28994 14.8751 3.04175 14.6269 3.04175 14.3207V9.47923ZM10.7501 9.47923V14.8751H16.2084C16.6226 14.8751 16.9584 14.5393 16.9584 14.1251V10.1251C16.9584 8.054 15.2795 6.37507 13.2084 6.37507H9.54632C10.294 7.19366 10.7501 8.28319 10.7501 9.47923Z" fill=""></path>
                            </svg>
                            Spam
                        </span>
                        <span >2</span>
                        </a>
                    </li>

                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 dark:text-gray-400" >
                        <span className="flex items-center gap-3">
                            <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M6.54118 3.7915C6.54118 2.54886 7.54854 1.5415 8.79118 1.5415H11.2078C12.4505 1.5415 13.4578 2.54886 13.4578 3.7915V4.0415H15.6249H16.6658C17.08 4.0415 17.4158 4.37729 17.4158 4.7915C17.4158 5.20572 17.08 5.5415 16.6658 5.5415H16.3749V8.24638V13.2464V16.2082C16.3749 17.4508 15.3676 18.4582 14.1249 18.4582H5.87492C4.63228 18.4582 3.62492 17.4508 3.62492 16.2082V13.2464V8.24638V5.5415H3.33325C2.91904 5.5415 2.58325 5.20572 2.58325 4.7915C2.58325 4.37729 2.91904 4.0415 3.33325 4.0415H4.37492H6.54118V3.7915ZM14.8749 13.2464V8.24638V5.5415H13.4578H12.7078H7.29118H6.54118H5.12492V8.24638V13.2464V16.2082C5.12492 16.6224 5.46071 16.9582 5.87492 16.9582H14.1249C14.5391 16.9582 14.8749 16.6224 14.8749 16.2082V13.2464ZM8.04118 4.0415H11.9578V3.7915C11.9578 3.37729 11.6221 3.0415 11.2078 3.0415H8.79118C8.37696 3.0415 8.04118 3.37729 8.04118 3.7915V4.0415ZM8.33325 7.99984C8.74747 7.99984 9.08325 8.33562 9.08325 8.74984V13.7498C9.08325 14.1641 8.74747 14.4998 8.33325 14.4998C7.91904 14.4998 7.58325 14.1641 7.58325 13.7498V8.74984C7.58325 8.33562 7.91904 7.99984 8.33325 7.99984ZM12.4166 8.74984C12.4166 8.33562 12.0808 7.99984 11.6666 7.99984C11.2524 7.99984 10.9166 8.33562 10.9166 8.74984V13.7498C10.9166 14.1641 11.2524 14.4998 11.6666 14.4998C12.0808 14.4998 12.4166 14.1641 12.4166 13.7498V8.74984Z" fill=""></path>
                            </svg>
                            Trash
                        </span>
                        </a>
                    </li>

                    <li className=" hover:bg-gray-300 rounded-lg">
                        <a href="#" className="flex items-center justify-between gap-2 rounded-lg px-3 py-2.5 text-sm font-medium hover:bg-brand-50 hover:text-brand-500 dark:hover:bg-brand-500/[0.12] dark:hover:text-brand-400 text-gray-500 dark:text-gray-400" >
                        <span className="flex items-center gap-3">
                            <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M1.54175 4.8335C1.54175 3.59085 2.54911 2.5835 3.79175 2.5835H16.2084C17.4511 2.5835 18.4584 3.59085 18.4584 4.8335V5.16683C18.4584 5.96477 18.0431 6.66569 17.4167 7.06517V15.1668C17.4167 16.4095 16.4094 17.4168 15.1667 17.4168H4.83341C3.59077 17.4168 2.58341 16.4095 2.58341 15.1668V7.06517C1.95711 6.66568 1.54175 5.96476 1.54175 5.16683V4.8335ZM4.08341 7.41683H15.9167V15.1668C15.9167 15.581 15.581 15.9168 15.1667 15.9168H4.83341C4.4192 15.9168 4.08341 15.581 4.08341 15.1668V7.41683ZM16.9584 5.16683C16.9584 5.58104 16.6226 5.91683 16.2084 5.91683H3.79175C3.37753 5.91683 3.04175 5.58104 3.04175 5.16683V4.8335C3.04175 4.41928 3.37753 4.0835 3.79175 4.0835H16.2084C16.6226 4.0835 16.9584 4.41928 16.9584 4.8335V5.16683ZM8.33341 9.04183C7.9192 9.04183 7.58341 9.37762 7.58341 9.79183C7.58341 10.206 7.9192 10.5418 8.33341 10.5418H11.6667C12.081 10.5418 12.4167 10.206 12.4167 9.79183C12.4167 9.37762 12.081 9.04183 11.6667 9.04183H8.33341Z" fill=""></path>
                            </svg>
                            Archive
                        </span>
                        </a>
                    </li>
                </ul>
            </div>
                
                    
            </div>  
                   
        </div>
            </div>

            <div className="bg-white mx-5 border rounded-2xl w-[900px] h-full min-h-screen">
                <div className="flex gap-3  ">
            <button  className=" mt-4 mx-4 flex w-16 items-center justify-between gap-2 rounded-lg border border-gray-200 p-3 dark:border-gray-800 sm:justify-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-white"  >
                <div className="form-check">
                    <input id=" default-checkbox" type="checkbox" value="" className="form-check-input w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 border"/>      
                </div>            
                <span  className="text-gray-500 duration-300 ease-linear dark:text-gray-400">
                    <svg className="stroke-current" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M3.83325 5.91699L7.99992 10.0837L12.1666 5.91699" stroke="" strokeWidth="1.5" strokeLinecap="round" stroke-linejoin="round"></path>
                    </svg>
                </span>
            </button>

            <button className="mt-4 flex h-10 w-full max-w-10 items-center justify-center rounded-lg border border-gray-200 text-gray-500 transition-colors hover:bg-gray-100 hover:text-gray-700 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6.72763 4.33443C7.92401 3.6437 9.30836 3.34945 10.6823 3.49385C12.0562 3.63826 13.3491 4.2139 14.3757 5.13828C15.0468 5.74252 15.5815 6.4755 15.9517 7.28815L13.6069 6.49282C13.2147 6.35977 12.7888 6.5699 12.6557 6.96216C12.5227 7.35443 12.7328 7.78028 13.1251 7.91333L16.8227 9.16752C16.8668 9.18743 16.9129 9.20314 16.9605 9.21426L17.0868 9.25712C17.2752 9.32101 17.4813 9.30746 17.6597 9.21943C17.838 9.1314 17.9741 8.97611 18.038 8.78772L19.3816 4.82561C19.5147 4.43334 19.3045 4.0075 18.9122 3.87447C18.52 3.74145 18.0941 3.95161 17.9611 4.34388L17.2335 6.48938C16.783 5.5609 16.1553 4.72223 15.3794 4.02356C14.1174 2.88722 12.528 2.17958 10.839 2.00207C9.15012 1.82455 7.44834 2.18628 5.97763 3.03539C4.50692 3.88451 3.34277 5.17743 2.65203 6.72884C1.9613 8.28025 1.77944 10.0105 2.13252 11.6716C2.4856 13.3328 3.3555 14.8395 4.61753 15.9758C5.87957 17.1121 7.46894 17.8198 9.15788 17.9973C10.8468 18.1748 12.5486 17.8131 14.0193 16.964C14.378 16.7569 14.5009 16.2982 14.2938 15.9395C14.0867 15.5807 13.628 15.4578 13.2693 15.6649C12.0729 16.3557 10.6886 16.6499 9.31467 16.5055C7.94077 16.3611 6.64786 15.7855 5.62123 14.8611C4.5946 13.9367 3.88697 12.711 3.59974 11.3598C3.31252 10.0085 3.46046 8.60098 4.02235 7.33894C4.58424 6.07691 5.53125 5.02516 6.72763 4.33443Z" fill="currentColor"></path>
                </svg>
            </button>

            <button className="mt-4 flex h-10 w-full max-w-10 items-center justify-center rounded-lg border border-gray-200 text-gray-500 transition-colors hover:bg-gray-100 hover:text-error-700 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-error-500">
                <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M6.54118 3.7915C6.54118 2.54886 7.54854 1.5415 8.79118 1.5415H11.2078C12.4505 1.5415 13.4578 2.54886 13.4578 3.7915V4.0415H15.6249H16.6658C17.08 4.0415 17.4158 4.37729 17.4158 4.7915C17.4158 5.20572 17.08 5.5415 16.6658 5.5415H16.3749V8.24638V13.2464V16.2082C16.3749 17.4508 15.3676 18.4582 14.1249 18.4582H5.87492C4.63228 18.4582 3.62492 17.4508 3.62492 16.2082V13.2464V8.24638V5.5415H3.33325C2.91904 5.5415 2.58325 5.20572 2.58325 4.7915C2.58325 4.37729 2.91904 4.0415 3.33325 4.0415H4.37492H6.54118V3.7915ZM14.8749 13.2464V8.24638V5.5415H13.4578H12.7078H7.29118H6.54118H5.12492V8.24638V13.2464V16.2082C5.12492 16.6224 5.46071 16.9582 5.87492 16.9582H14.1249C14.5391 16.9582 14.8749 16.6224 14.8749 16.2082V13.2464ZM8.04118 4.0415H11.9578V3.7915C11.9578 3.37729 11.6221 3.0415 11.2078 3.0415H8.79118C8.37696 3.0415 8.04118 3.37729 8.04118 3.7915V4.0415ZM8.33325 7.99984C8.74747 7.99984 9.08325 8.33562 9.08325 8.74984V13.7498C9.08325 14.1641 8.74747 14.4998 8.33325 14.4998C7.91904 14.4998 7.58325 14.1641 7.58325 13.7498V8.74984C7.58325 8.33562 7.91904 7.99984 8.33325 7.99984ZM12.4166 8.74984C12.4166 8.33562 12.0808 7.99984 11.6666 7.99984C11.2524 7.99984 10.9166 8.33562 10.9166 8.74984V13.7498C10.9166 14.1641 11.2524 14.4998 11.6666 14.4998C12.0808 14.4998 12.4166 14.1641 12.4166 13.7498V8.74984Z" fill=""></path>
                </svg>
            </button>

            <button className="mt-4 flex h-10 w-full max-w-10 items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-700 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white">
                <svg className="text-primary fill-current" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M1.54163 4.8335C1.54163 3.59085 2.54899 2.5835 3.79163 2.5835H16.2083C17.4509 2.5835 18.4583 3.59085 18.4583 4.8335V5.16683C18.4583 5.96477 18.0429 6.66569 17.4166 7.06517V15.1668C17.4166 16.4095 16.4093 17.4168 15.1666 17.4168H4.83329C3.59065 17.4168 2.58329 16.4095 2.58329 15.1668V7.06517C1.95699 6.66568 1.54163 5.96476 1.54163 5.16683V4.8335ZM4.08329 7.41683H15.9166V15.1668C15.9166 15.581 15.5808 15.9168 15.1666 15.9168H4.83329C4.41908 15.9168 4.08329 15.581 4.08329 15.1668V7.41683ZM16.9583 5.16683C16.9583 5.58104 16.6225 5.91683 16.2083 5.91683H3.79163C3.37741 5.91683 3.04163 5.58104 3.04163 5.16683V4.8335C3.04163 4.41928 3.37741 4.0835 3.79163 4.0835H16.2083C16.6225 4.0835 16.9583 4.41928 16.9583 4.8335V5.16683ZM8.33329 9.04183C7.91908 9.04183 7.58329 9.37762 7.58329 9.79183C7.58329 10.206 7.91908 10.5418 8.33329 10.5418H11.6666C12.0808 10.5418 12.4166 10.206 12.4166 9.79183C12.4166 9.37762 12.0808 9.04183 11.6666 9.04183H8.33329Z" fill="currentColor"></path>
                </svg>
            </button>

            <button  className="mt-4 flex h-10 w-full max-w-10 items-center justify-center rounded-lg border border-gray-200 transition-colors hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-gray-800 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-white" >
          <svg className="text-primary fill-current" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.2441 6C10.2441 5.0335 11.0276 4.25 11.9941 4.25H12.0041C12.9706 4.25 13.7541 5.0335 13.7541 6C13.7541 6.9665 12.9706 7.75 12.0041 7.75H11.9941C11.0276 7.75 10.2441 6.9665 10.2441 6ZM10.2441 18C10.2441 17.0335 11.0276 16.25 11.9941 16.25H12.0041C12.9706 16.25 13.7541 17.0335 13.7541 18C13.7541 18.9665 12.9706 19.75 12.0041 19.75H11.9941C11.0276 19.75 10.2441 18.9665 10.2441 18ZM11.9941 10.25C11.0276 10.25 10.2441 11.0335 10.2441 12C10.2441 12.9665 11.0276 13.75 11.9941 13.75H12.0041C12.9706 13.75 13.7541 12.9665 13.7541 12C13.7541 11.0335 12.9706 10.25 12.0041 10.25H11.9941Z" fill=""></path>
          </svg>
        </button>

        <div className="mx-[150px] flex justify-end mt-4 relative w-full sm:max-w-[236px]">
            <form>
                <button className="mt-2 absolute left-4 top-3 -translate-y-1/2">
                <svg className="fill-gray-500 dark:fill-gray-400" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M3.04199 9.37381C3.04199 5.87712 5.87735 3.04218 9.37533 3.04218C12.8733 3.04218 15.7087 5.87712 15.7087 9.37381C15.7087 12.8705 12.8733 15.7055 9.37533 15.7055C5.87735 15.7055 3.04199 12.8705 3.04199 9.37381ZM9.37533 1.54218C5.04926 1.54218 1.54199 5.04835 1.54199 9.37381C1.54199 13.6993 5.04926 17.2055 9.37533 17.2055C11.2676 17.2055 13.0032 16.5346 14.3572 15.4178L17.1773 18.2381C17.4702 18.531 17.945 18.5311 18.2379 18.2382C18.5308 17.9453 18.5309 17.4704 18.238 17.1775L15.4182 14.3575C16.5367 13.0035 17.2087 11.2671 17.2087 9.37381C17.2087 5.04835 13.7014 1.54218 9.37533 1.54218Z" fill=""></path>
                </svg>
                </button>
                <input type="text" placeholder="Search..." className="dark:bg-dark-900 h-10 w-full rounded-lg border border-gray-300 bg-transparent px-4 py-2.5 pl-[42px] text-sm text-gray-800 shadow-theme-xs placeholder:text-gray-400 focus:border-brand-300 focus:outline-hidden focus:ring-3 focus:ring-brand-500/10 dark:border-gray-700 dark:text-white/90 dark:placeholder:text-white/30 dark:focus:border-brand-800"/>
            </form>
        </div>

                </div> 
                <hr className="mt-2 border-b"/>


                <div className="max-w-4xl mx-auto">
        
        {!selectedEmail ? (
          <div className="space-y-4">
            {emails.map((email) => (
                
              <div key={email.id} className="bg-white rounded shadow p-2 flex justify-between items-center">
                <div className="flex gap-8">
                    <div className="mt-2">
                        <input id=" default-checkbox" type="checkbox" value="" className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 border"/>           
                    </div>
                    <div className="mt-1"><Star/></div>
                    
                </div>
                     
                
                <div className=" w-[500px]">
                  <h2 className="text-xl font-semibold">{email.subject}</h2>
                  <p className="text-gray-500 text-sm">From: {email.sender}</p>
                  
                </div>
                <span className="justify-end font-bold text-gray-500 text-[15px]">{email.time}</span>
                <button onClick={() => setSelectedEmail(email)} className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg">View</button>
              </div>
            ))}
          </div>
        ) : (
          
          <div className="bg-white rounded shadow p-6">
            <button onClick={() => setSelectedEmail(null)} className="h-[35px] rounded-lg w-[150px] bg-blue-600 text-white  mb-4 inline-block">
                <div className="mx-3 flex gap-2">
                    <i className="mt-1 fa-solid fa-arrow-left"></i>
                    Back to Inbox
                </div>
                 
            </button>
            <h2 className="text-2xl font-bold mb-2">{selectedEmail.subject}</h2>
            <p className="text-gray-600 mb-4">From: {selectedEmail.sender}</p>
            <p className="text-gray-800">{selectedEmail.body}</p>            
            <p className="mt-4 text-gray-800">{selectedEmail.content}</p>
            <p className="mt-4 text-gray-800">{selectedEmail.last}</p>
            
          </div>
        )}
                </div>        
            </div>

        </div>        
        </>
    )
}
export default Mail