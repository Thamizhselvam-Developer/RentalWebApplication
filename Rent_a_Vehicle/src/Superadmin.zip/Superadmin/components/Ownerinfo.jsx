import { useState } from "react";
import Arrow from "../../assets/Arrow.png";
import Owner from "../../assets/Owner/Owener 1.png";

import RentalFormViews from "./RentalFormViews";
import Calendar from "./Calendar";
const Ownerinfo = () => {
  const Ownerdetails = [
    {
      id: 1,
      img: Owner,
      name: "Thamizhselvam",
      mail: "thamizhselvam8428@gmail.com",
      number: "+91 8428961472",
      Shopname: "Maruthi Rentanls",
      Status: "Approved",
    },
    {
      id: 2,
      img: Owner,
      name: "Karthi",
      mail: "karthi@gmail.com",
      number: "+91 8428961472",
      Shopname: "Annai Rentanls",
      Status: "Pending",
    },
    {
      id: 3,
      img: Owner,
      name: "Karthiga",
      mail: "karthiga@gmail.com",
      number: "+91 8428961472",
      Shopname: "wheel Rentanls",
      Status: "Cancelled",
    },
    {
      id: 4,
      img: Owner,
      name: "priya",
      mail: "priya@gmail.com",
      number: "+91 8428961472",
      Shopname: "Cyro Rentanls",
      Status: "Approved",
    },
    {
      id: 4,
      img: Owner,
      name: "Jenith",
      mail: "jenith@gmail.com",
      number: "+91 8428961472",
      Shopname: "Mart Rentanls",
      Status: "Cancelled",
    },
    {
      id: 6,
      img: Owner,
      name: "Sabitha",
      mail: "thamizhselvam8428@gmail.com",
      number: "+91 8428961472",
      Shopname: "Kathirvel Rentanls",
      Status: "Pending",
    },
  ];

  const [Show, SetShow] = useState(false);
  
  const toadd=()=>{
    SetShow(true)

  }
  const Close = () => {
    SetShow(false); 
  };

//   function tocount() {
//     console.log("HI");
//   }
  return (
    <>
      <div className="relative ">
        <div className=" flex items-center mt-5  tracking-wider gap-2 ml-6 font-Open ">
          <span>Home</span>
          <img src={Arrow} className="w-[10px] h-[10px] " />
          <span className="font-bold text-primary  text-[15px]">
            {" "}
            Ownerinfo
          </span>
        </div>

        <div className="grid grid-cols-3  ">
          {Ownerdetails.map((items, i) => (
            <>
              <div
                key={i}
                className="bg-white p-6 rounded-2xl shadow-md w-[350px] relative ml-4 mt-5"
              >
                <div className="w-[36px] h-[36px]  hover:text-black absolute right-2 mt-1 text-center rounded-3xl ">
                  <i className="fa-solid fa-pencil mt-2 hover:text-black   text-primary"></i>
                </div>
                <div className="flex justify-center mb-4">
                  <div className="rounded-full bg-gray-100 p-1 w-20 h-20">
                    <img
                      src={items.img}
                      className="rounded-full w-full h-full object-cover"
                    />
                  </div>
                </div>

                <h2 className="text-center text-gray-800 font-medium text-lg mb-4">
                  <span>{items.name}</span>
                </h2>

                <div className="space-y-2">
                  <div className="border border-gray-200 rounded-lg p-3 text-gray-600 text-center">
                    {items.mail}
                  </div>
                  <div className="border border-gray-200 rounded-lg p-3 text-gray-600 text-center">
                    {items.number}
                  </div>
                  <div className="border border-gray-200 rounded-lg p-3 text-gray-600 text-center">
                    {items.Shopname}
                  </div>

                  <div
                    onClick={() => toadd()}
                    className="border border-gray-200 rounded-lg p-3 text-gray-600 text-center hover:cursor-pointer"
                  >
                    View
                  </div>

                  {items.Status && (
                    <div
                      className={`border border-gray-200   text-white rounded-lg p-3  text-center

    ${items.Status === "Approved" ? "bg-green-400 text-white" : " "}
    
    ${items.Status === "Pending" ? "bg-primary " : " "}
       ${items.Status === "Cancelled" ? "bg-yellow-400 " : " "}
`}
                    >
                      {items.Status}
                    </div>
                  )}
                </div>
              </div>
            </>
          ))}

          {Show &&(
            <div className="w-full">
              <div className=" absolute left-[0px] top-0 backdrop-blur-sm bg-black/50 h-full z-10 w-full  ">
                <div>
                  <RentalFormViews Close={Close}/>
                </div>
              </div>
            </div>
          ) }
        </div>
      </div>
    </>
  );
};
export default Ownerinfo;
