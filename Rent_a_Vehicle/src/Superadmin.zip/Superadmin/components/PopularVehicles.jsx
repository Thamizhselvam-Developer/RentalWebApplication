
import { PopularVehicles } from "../../Db/PopularVehicles";

function Popular(){
    
    return(
        <>
        {/* <div className="">
            <div className="mt-5  bg-white  w-[300px] rounded-xl h-[318px] ">
                <div className="mt-6 font-bold text-[20px] mx-5 text-center  ">
                    
                   <span className=""> Popular Vehicle </span></div> */}
                {/* <span className="mt-5 font-bold text-[20px] mx-5  ">Popular Vehicle</span> */}
                {/* {PopularVehicles.map((items)=>(
                    <div className="mt-5  justify-between" key={items.id}>
                        <div className="mx-5 flex gap-5">
                            <div className="w-[70px]">
                                <img className=" h-[50px] rounded-2xl object-cover" src={items.logo} alt="" />
                            </div>                    
                            <div className="grid grid-cols-1 mt-1">
                                <span className="font-bold text-[16px]">{items.span1}</span>
                                <span className="text-[14px]">{items.span2}</span>
                            </div>                    
                        </div>

                        <div className="mx-5 mt-4 border-b-2 border-gray-300"></div>
                         */}

                        {/* <div className="grid grid-cols-1 mx-3 mt-1 ">
                            <span className="font-bold text-[16px]">{items.span3}</span>
                            <span className="text-[14px]">{items.span4}</span>
                        </div> */}
                    {/* </div>              */}

        {/* //         ))} */}
                   
        {/* //     </div> */}
        {/* // </div> */}
        </>
    )



}

export default Popular;