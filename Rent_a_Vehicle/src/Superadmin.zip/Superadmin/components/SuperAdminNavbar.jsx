
import React, { useState } from "react";
import profileImg from "../../assets/admin_profile_img.png";
import { HiMenuAlt3 } from "react-icons/hi";
import profile from "../../assets/profile.png"
import { Link } from "react-router-dom";


const S_A_navbar = ({ setOpenSidebar }) => {
  return (
    <div className="px-5 py-3 flex justify-around md:justify-between items-center md:px-6 md:py-3 bg-white shadow-sm border-b border-gray-200">
      <div className="  lg:text-xl lg:font-semibold text-gray-800 cursor-pointer">
        Super Admin Dashboard
      </div>
      
      <div className="flex gap-5">
        <div className="border rounded-lg bg-white w-[45px] h-[40px] flex justify-center items-center text-[20px]">
          <i className="fa-solid fa-magnifying-glass" />
        </div>

        <div className="border rounded-lg bg-white w-[45px] h-[40px] flex justify-center items-center text-[20px]">
          <i className="fa-solid fa-gear"></i>
        </div>

        <div className=" cursor-pointer border rounded-lg bg-white w-[45px] h-[40px] text-center text-[20px] hidden md:block relative">
          <div className="mt-1">
            <i className="fa-solid fa-bell text-gray-600 text-lg" />
            <div>
              <span className="absolute top-2 left-[25px]  block h-2 w-2 rounded-full animate-pulse bg-red-500 ring-2 ring-white" />
            </div>
          </div>       
        </div>

         <div className="border rounded-lg bg-white w-[45px] h-[40px] flex justify-center items-center text-[20px]">
          <img src={profile} alt="" width="35px"/>
        </div>
        <Link to="Profile-info">
        <div className="grid grid-cols-1 ">
          <span className="font-Outfit font-bold tracking-wide">God Vishnu</span>
          <span className="tracking-wider font-Outfit">Admin</span>
        </div>
        </Link>
      
      </div>

        <div className="md:hidden">
          <HiMenuAlt3 size={24} className="cursor-pointer" onClick={() => setOpenSidebar(true)} />
        </div>
      </div>
    
  );
};

export default S_A_navbar;